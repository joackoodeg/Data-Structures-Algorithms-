#include <iostream>
#include <tree.hpp>
#include <string>
#include <list>
#include <lisp.hpp>
#include <graphviz.hpp>
#include <map>
using namespace aed;
using namespace std;

void showL(list<int>&L){
	for(auto i: L){cout<<i<<" ";}cout<<endl;
}

//aux
void list2tree(tree<int>& T, list<int>& L, tree<int>::iterator it, list<int>::iterator itL){
	if(itL==L.end()){return;}
	//agregar el nodo
	it=T.insert(it, *itL);
	//obtener la cantidad de hijos del nodo
	itL++;
	int n_hijos = *itL;
	itL++;
	//reconstruir los hijos
	auto h = it.lchild();

	//por cada hijo, haer a recursion con list2tree
	for(int i =0; i<n_hijos; i++){
		list2tree(T,L,h,itL);
		// h++;
	}
}	
	
//wrapper
void list2tree(tree<int>& T, list<int>& L){
	list<int>::iterator itL= L.begin();
	tree<int>::iterator it=T.begin();
	list2tree(T,L,it,itL);
}	

int main() {
	
	tree<int>arbol;
	
	list<int>L = {6, 5, 4, 0, 8, 0, 5, 2, 4, 0, 4, 0, 7, 0, 9, 0};
	
	list2tree(arbol,L);
	tree2dot(arbol);
	
	return 0;
}







