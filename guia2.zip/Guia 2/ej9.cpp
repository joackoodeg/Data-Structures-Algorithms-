#include <iostream>
using namespace std;

//Camale�on. Implemente los predicados bool menor(int x, int y), bool mayor(int x, int y)
//	y bool dist(int x, int y) que retornen verdadero si x es menor, mayor o menor en valor
//	absoluto que y respectivamente. Luego implemente una funci�on
//	ordena(list<int> &L, bool (*f)(int,int)) que ordene la lista L dependiendo de la funci�on
//	f pasada c�omo par�ametro.

int main() {
	
	return 0;
}






